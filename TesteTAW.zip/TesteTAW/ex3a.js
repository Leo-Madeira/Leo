Math.floor(Math.random(Num)%2==0)
alert(Num)